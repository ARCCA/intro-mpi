#!/bin/env python3
# Demonstration of the imposition of a simple cartesian geometry on a set of
# processes. In this case we generate a uniform 2-D grid in which each
# element passes a value to its nearest neighbour to the right.

from mpi4py import MPI
import numpy as np
import math

if __name__ == "__main__":

    # Initialise the MPI communicator and get the rank and total number of
    # processes.
    try:
        comm = MPI.COMM_WORLD
        rank = comm.Get_rank()
        size = comm.size
    except Exception as err:
        sys.exit("Error: %s" % err)

    # We want to create a square array of elements, so take the square root
    # of the number of processes to get the length of each axis.
    axis = math.isqrt(size)  # or int(np.sqrt(size))
    assert axis * axis == size, "Number of processes must be a perfect square!"

    # Create a cartesian geometry communicator, with no wrapping at the edges.
    cart = comm.Create_cart(dims=(axis, axis),
                            periods=(False, False), reorder=True)

    # Return the process this rank will be receiving data from, and the one it
    # will be sending it to. Then print out a summary.
    source, dest = cart.Shift(direction=0, disp=1)
    coord = tuple(cart.Get_coords(rank))
    print ("Rank:",rank,"Co-ords:", coord," : Source =",source," Dest =",dest)

    # Create buffers for sending and receiving data. The send buffer contains
    # an integer representing the coordinates of this process and the receive
    # buffer is empty.
    sendbuf = np.array(int("%d%d" % (coord[0], coord[1])))
    recvbuf = np.array(-2)

    # Send and receive data in one operation, and print out the result.
    cart.Sendrecv(sendbuf, dest=dest, recvbuf=recvbuf, source=source)
    print ("Rank:",rank," Sent:",sendbuf," Received:",recvbuf)
